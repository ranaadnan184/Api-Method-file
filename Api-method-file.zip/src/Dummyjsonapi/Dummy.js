import React from "react";
import "./style.css";
import { useState, useEffect } from "react";
export default function Dummy() {
  const [data, setData] = useState([]);
  // const [imagess, setImages] = useState("");
  const Handleclick = () => {
    fetch("https://dummyjson.com/products")
      .then((res) => res.json())
      .then((item) => setData(item.products));
  };
  // console.log(data);
  useEffect(() => {
    return () => {
      Handleclick();
    };
  }, []);
  // {setImages(data.images)}

  // console.log(imagess)
  return (
    <div className="dummy-json-data">
      <h1>fetch data from live server</h1>

      {/* <button onClick={Handleclick}> Click me</button> */}
      <div className="Main-card-dummy">
        {data.map((item, i) => {
          return (
            <div className="inner-dummy-card">
              <h1>{item.id}</h1>

              {item.images.map((items) => {
                return (
                  <div className="inner-img-dummy">
                    <img src={items} alt="" />
                  </div>
                );
              })}

              <h2>{item.title}</h2>
              <p>{item.description}</p>
              <p>{item.price}</p>
              <p>{item.discountPercentage}</p>
              <p>{item.brand}</p>
            </div>
          );
        })}
      </div>
    </div>
  );
}
