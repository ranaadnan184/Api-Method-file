import React, { useState } from "react";
import "../../Dummyjsonapi/style.css";
const PostFakecart = () => {
  const [userid, setUserid] = useState("");
  const [date, setDate] = useState("");
  const [quantity, setQuantity] = useState("");
  const [prodect, setProdect] = useState("");
  const handleClick = async () => {
    let data = { userid, date, quantity, prodect };
    await fetch("https://fakestoreapi.com/carts", {
      method: "POST",
      headers: {
        accept: "application/json",
        "content-type": "application/json",
      },
      body: JSON.stringify(data),
    }).then((response) => {
      response.json().then((item) => {
        console.log("items", item);
      });
    });
  };
  return (
    <div>
      <div className="main-form">
        <div className="inner-form-text">
          <div>
            <lable>User Id</lable>
            <input
              type="text"
              placeholder="User Id"
              name="User Id"
              value={userid}
              onChange={(e) => {
                setUserid(e.target.value);
              }}
            />
          </div>
          <div>
            <lable>Date</lable>
            <input
              type="date"
              placeholder="Date"
              name="Date"
              value={date}
              onChange={(e) => {
                setDate(e.target.value);
              }}
            />
          </div>
          <div>
            <lable>Quantity</lable>
            <input
              type="text"
              placeholder="Quantity"
              name="quantity"
              value={quantity}
              onChange={(e) => {
                setQuantity(e.target.value);
              }}
            />
          </div>
          <div>
            <lable>Prodect ID</lable>
            <input
              type="text"
              placeholder="Prodect Id"
              name="Prodect"
              value={prodect}
              onChange={(e) => {
                setProdect(e.target.value);
              }}
            />
          </div>
          <div>
            <button onClick={handleClick} type="button">
              Submit
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PostFakecart;
