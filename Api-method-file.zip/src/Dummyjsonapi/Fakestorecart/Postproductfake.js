import React, { useState } from "react";
import "../../Dummyjsonapi/style.css";

const Postproductfake = () => {
  const [userid, setUserid] = useState("");
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [image, setImage] = useState("");
  const handleClick = async () => {
    const data = { userid, title, description, image };

    fetch("https://fakestoreapi.com/products", {
      method: "POST",
      headers: {
        accept: "application/json",
        "content-type": "application/json",
      },
      body: JSON.stringify(data),
    }).then((response) => {
      response.json().then((post) => {
        console.log("Postdata", post);
      });
    });
  };
  return (
    <div>
      <div className="main-form">
        <div className="inner-form-text">
          <div>
            <lable>Id</lable>
            <input
              type="text"
              placeholder="User Id"
              name="User Id"
              value={userid}
              onChange={(e) => {
                setUserid(e.target.value);
              }}
            />
          </div>
          <div>
            <lable>title</lable>
            <input
              type="text"
              placeholder="title"
              name="title"
              value={title}
              onChange={(e) => {
                setTitle(e.target.value);
              }}
            />
          </div>
          <div>
            <lable>description</lable>
            <input
              type="text"
              placeholder="Description"
              name="description"
              value={description}
              onChange={(e) => {
                setDescription(e.target.value);
              }}
            />
          </div>
          <div>
            <lable>image</lable>
            <input
              type="file"
              placeholder="Select image"
              name="image"
              value={image}
              onChange={(e) => {
                setImage(e.target.value);
              }}
            />
          </div>
          <div>
            <button onClick={handleClick} type="button">
              Submit
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Postproductfake;
