import React, { useState, useEffect } from "react";
import "./Style.css";
export default function Fcart() {
  const [data, setData] = useState([]);
  const [title, setTitle] = useState("");
  const [price, setPrice] = useState("");
  const [quantity, setQuantity] = useState("");
  const [userid, setUserid] = useState("");
  useEffect(() => {
    return () => {
      HandleCard();
    };
  }, []);
  const HandleCard = async () => {
    await fetch("https://dummyjson.com/carts")
      .then((res) => res.json())
      .then((item) => {
        setData(item.carts);
      });
  };
     const Updateuserid=()=>{
      let itemsss={title,price,quantity,userid}
      console.log("data",itemsss)
      fetch(`https://dummyjson.com/carts/${userid}`, {
        method: "PUT",
        headers:{
          'Accept':"application/json",
          'Content-tyoe':"application/json",
        },
        body:JSON.stringify(itemsss)
       
      }).then((result) => {
        result.json().then((resp) => {
          console.log("response", resp);
        });
      });
     }
     
  // console.log("data", data);
  const Updatehandle = (id) => {
    // setTitle(data[id].title);
    // console.log(id);
    data.map((item) => {
      item.products.filter((items) => {
        if (id == items.id) {
          // console.log(items);
          setTitle(items.title);
          setQuantity(items.quantity);
          setUserid(items.id);
          setPrice(items.price);
        }
      });
    });
  };
  return (
    <div className="main-api-sote">
      <div className="inner-card-first">
        {data.map((A, i) => {
          return (
            <>
              <div className="inner-card-second">
                {A.products.map((ab, id) => {
                  return (
                    <div key={id}>
                      <h3>ID::{ab.id}</h3>
                      <h5>{ab.title}</h5>
                      <h1>{ab.price}</h1>
                      <p>{ab.quantity}</p>
                      <button
                        onClick={() => {
                          Updatehandle(ab.id);
                        }}
                      >
                        Update
                      </button>
                    </div>
                  );
                })}
              </div>
            </>
          );
        })}
      </div>
      <div className="Main-text-box-1">
        <div className="">
          <div>User Id</div>
          <input type="text" value={userid} onChange={(e)=>{setUserid(e.target.value)}}/>
        </div>
        <div>
          <div>Title</div>
          <input type="text" value={title}  onChange={(e)=>{setTitle(e.target.value)}} />
        </div>
        <div>
          <div>Price</div>
          <input type="text" value={price}  onChange={(e)=>{setPrice(e.target.value)}}/>
        </div>
        <div>
          <div>Quantity</div>
          <input type="text" value={quantity}  onChange={(e)=>{setQuantity(e.target.value)}} />
        </div>
        <div><button onClick={Updateuserid}>Updateuser</button></div>
      </div>
    </div>
  );
}
