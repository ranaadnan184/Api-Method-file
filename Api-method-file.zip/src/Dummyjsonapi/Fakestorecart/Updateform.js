import React from 'react';

function Updateform() {
  return (
    <div>
      Yes this is Update form
    </div>
  );
}

export default Updateform;
