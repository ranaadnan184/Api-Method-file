import React, { useState, useEffect } from "react";

const Fakestorecart = () => {
  const [data, setData] = useState([]);
  const Handlecart = async () => {
    await fetch("https://fakestoreapi.com/carts")
      .then((res) => res.json())
      .then((json) => setData(json));
  };
  useEffect(() => {
    return () => {
      Handlecart();
    };
  }, []);
  return (
    <div>
      {data.map((item) => {
        return (
          <div>
            <h1>Id:{item.id}</h1>
            <h4>{item.userId}</h4>
            <p>date {item.date.slice(0,10)}</p>
            {item.products.map((items) => {
              return (
                <>
                  <h4>ProductId{items.productId}</h4>
                  <h5>quantity{items.quantity}</h5>
                </>
              );
            })}
          </div>
        );
      })}
    </div>
  );
};

export default Fakestorecart;
