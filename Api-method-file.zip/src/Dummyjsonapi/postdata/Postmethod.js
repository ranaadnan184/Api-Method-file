import React, { useState } from "react";
import "../style.css";
export default function Postmethod() {
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [email, setEmail] = useState("");
  const [address, setAddress] = useState("");
  const handleClick = () => {
    let data = { name, phone, email, address };
    fetch("https://dummyjson.com/products/", {
      method: "POST",
      headers: {
        accept: "application/json",
        "content-type": "application/json",
      },
      body: JSON.stringify(data),
    }).then((response) => {
      response.json().then((resp) => {
        console.log("response", resp);
      });
    });
  };
  return (
    <div className="main-form">
      <div className="inner-form-text">
        <div>
          <lable>User Name</lable>
          <input
            type="text"
            placeholder="user name"
            name="name"
            value={name}
            onChange={(e) => {
              setName(e.target.value);
            }}
          />
        </div>
        <div>
          <lable>Phone</lable>
          <input
            type="text"
            placeholder="Phone"
            name="phone"
            value={phone}
            onChange={(e) => {
              setPhone(e.target.value);
            }}
          />
        </div>
        <div>
          <lable>Email</lable>
          <input
            type="text"
            placeholder="Email"
            name="email"
            value={email}
            onChange={(e) => {
              setEmail(e.target.value);
            }}
          />
        </div>
        <div>
          <lable>Address</lable>
          <input
            type="text"
            placeholder="Address"
            name="address"
            value={address}
            onChange={(e) => {
              setAddress(e.target.value);
            }}
          />
        </div>
        <div>
          <button onClick={handleClick} type="button">
            Submit
          </button>
        </div>
      </div>
    </div>
  );
}
