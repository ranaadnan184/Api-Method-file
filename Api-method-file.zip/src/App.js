import './App.css';
import Postproductfake from './Dummyjsonapi/Fakestorecart/Postproductfake';
import Fakestorecart from './Dummyjsonapi/Fakestorecart/Fakestorecart';
import PostFakecart from './Dummyjsonapi/Fakestorecart/PostFakecart';
import Fcart from '../src/Dummyjsonapi/Fakestorecart/Fcart';
// import Dummy from './Dummyjsonapi/Dummy';
// import Postmethod from './Dummyjsonapi/postdata/Postmethod';
// import {BrowserRouter as Router,Routes,Route} from "react-router-dom";

// import Fakedata from './FakestoreApi/Fakedata';

function App() {
  return (
    <div className="App">
      {/* <Router> */}
      {/* <Dummy/> */}
      {/* <Postmethod/> */}


     {/* fetch get and post usin asaync and await   */}
     
      {/* <Fakestorecart/> */}
      {/* <PostFakecart/> */}
      {/* <Postproductfake/> */}


      {/* Delete data fake api  */}
      {/* <Fakedata/> */}
  




      {/* prefilled form  and update api  data  */}

    <Fcart/>
      
    </div>
  );
}

export default App;
