import React from "react";
import { useEffect, useState } from "react";
import "./style.css";
export default function Fakedata() {
  const [data, setData] = useState([]);
  const handleDatafake = () => {
    fetch("https://fakestoreapi.com/products")
      .then((res) => res.json())
      .then((item) => setData(item));
  };

  const Deletedata = (id) => {
    fetch(`https://fakestoreapi.com/products/${id}`, {
      method: "DELETE",
    }).then((result) => {
      result.json().then((resp) => {
        console.log("response", resp);
      });
    });
  };
  useEffect(() => {
    return () => {
      handleDatafake();
    };
  }, []);

  return (
    <div className="main-fake-store-api">
      {data.map((item, i) => {
        return (
          <div className="inner-fake-data">
            <h1>ID:{item.id}</h1>
            <h5>Title:{item.title}</h5>
            <h3>Price:{item.price}</h3>
            <span>Description:{item.description}</span>
            <div className="inner-fake-data1">
              <img src={item.image} alt="" />
              <button
                onClick={() => {
                  Deletedata(item.id);
                }}
                id="Dellbtn"
              >
                Delete
              </button>
            </div>
          </div>
        );
      })}
    </div>
  );
}
